#!/usr/bin/env python3
"""
INTERN FARM — toolchain farming API key Intern/OpenXLab (portable, 5 fase).

Cara pakai:
    python farm.py --status                # cek config + dependensi (masked)
    python farm.py --register [--count N] [--start IDX]   # fase 1: buat akun
    python farm.py --scan                  # fase 2: scan IMAP cari link aktivasi
    python farm.py --activate              # fase 3: aktivasi massal via HTTP
    python farm.py --login  [--count N]    # fase 4: login + create API key
    python farm.py --insert                # fase 5: insert key ke 9router
    python farm.py --all    [--count N] [--start IDX]     # 1->5 berurutan

Semua pengaturan dibaca dari config.env (lihat file itu). Path output relatif
ke folder script ini (state/, keys/, logs/), jadi bisa di-copy ke mesin lain
(Windows/Linux) dan langsung jalan.

Alur proven (pipeline yang berhasil jebol 45 akun):
  register (Playwright + RSA + proxy sid-rotate)
  -> scan IMAP (regex link aktivasi dari dm.openxlab.org.cn)
  -> activate (POST register/active {sign,token}, retry 3x proxy beda)
  -> login+key (BrowserSession reuse, DiscoveryClient create_key)
  -> insert 9router (sqlite3 providerConnections, providerSpecificData lengkap)
"""
import os
import sys
import json
import time
import base64
import hmac
import hashlib
import random
import string
import imaplib
import email
import re
import glob
import sqlite3
import urllib.request
import urllib.error
import subprocess
import threading
import argparse
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(BASE, "lib")
STATE = os.path.join(BASE, "state")
KEYS = os.path.join(BASE, "keys")
LOGS = os.path.join(BASE, "logs")
CONFIG = os.path.join(BASE, "config.env")
ACCOUNTS_JSON = os.path.join(STATE, "accounts.json")
ACTMAP_JSON = os.path.join(STATE, "activation_map.json")
ACTIVATED_JSON = os.path.join(STATE, "activated.json")
KEYS_JSONL = os.path.join(KEYS, "keys.jsonl")

# ============================================================
# Config loader
# ============================================================
CFG = {}


def load_config():
    global CFG
    if not os.path.exists(CONFIG):
        sys.exit(f"[!] config.env tidak ditemukan di {CONFIG}")
    for ln in open(CONFIG, encoding="utf-8"):
        ln = ln.strip()
        if not ln or ln.startswith("#") or "=" not in ln:
            continue
        k, _, v = ln.partition("=")
        CFG[k.strip()] = v.strip().strip('"').strip("'")


def cfg(key, default=""):
    v = CFG.get(key)
    return v if v not in (None, "") else default


def mask(v):
    v = str(v)
    if not v:
        return "(kosong)"
    return v[:4] + "..." + v[-2:] if len(v) > 8 else "***"


def ensure_dirs():
    for d in (STATE, KEYS, LOGS):
        os.makedirs(d, exist_ok=True)


def log(msg):
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(os.path.join(LOGS, "farm.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


# ============================================================
# Fase 1: REGISTER (Playwright + RSA + proxy sid-rotate)
# ============================================================
def email_for(idx):
    return f"{cfg('EMAIL_BASE')}+{cfg('TAG_PREFIX')}{idx}x@{cfg('EMAIL_DOMAIN')}"


def uname_for(idx):
    return f"{cfg('TAG_PREFIX')}{idx}x"


def load_accounts():
    if os.path.exists(ACCOUNTS_JSON):
        try:
            return json.load(open(ACCOUNTS_JSON))
        except Exception:
            return []
    return []


def save_accounts(accs):
    json.dump(accs, open(ACCOUNTS_JSON, "w"), indent=1)


def register_attempt(ses, email, uname):
    """Satu percobaan register. Kembalikan (cls, j, ip, note) — sama persis
    logika farm45_plus.py yang jebol."""
    from playwright.sync_api import sync_playwright

    proxy_cfg = {
        "server": f"http://{cfg('PROXY_HOST')}:{cfg('PROXY_PORT')}",
        "username": f"{cfg('PROXY_USER')}__sid.{ses}",
        "password": cfg("PROXY_PASS"),
    }
    # chrome path dari config (kosong -> biarkan Playwright cari default)
    launch_kw = dict(
        headless=True,
        args=[
            "--enable-unsafe-swiftshader", "--use-gl=angle", "--use-angle=swiftshader",
            "--disable-gpu-sandbox", "--no-sandbox", "--disable-dev-shm-usage",
            "--window-size=1280,900",
        ],
    )
    cp = cfg("CHROME_PATH")
    if cp:
        launch_kw["executable_path"] = cp

    with sync_playwright() as pw:
        browser = pw.chromium.launch(**launch_kw)
        ctx = browser.new_context(
            proxy=proxy_cfg,
            locale="zh-CN", timezone_id="Asia/Shanghai",
            viewport={"width": 1280, "height": 800},
            user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
        )
        page = ctx.new_page()
        try:
            page.goto(cfg("SSO_BASE") + "/register", timeout=40000, wait_until="domcontentloaded")
        except Exception:
            pass
        time.sleep(2)
        ip = None
        try:
            ip = page.evaluate("fetch('https://api.ipify.org?format=json').then(r=>r.json()).then(j=>j.ip)")
        except Exception:
            pass
        pk = None
        try:
            resp = page.request.post(cfg("SSO_BASE") + "/gw/uaa-be/api/v1/cipher/getPubKey",
                                     data=json.dumps({"type": "register", "from": "browser"}),
                                     headers={"Content-Type": "application/json"})
            j = json.loads(resp.text())
            pk = j.get("data", {}).get("pubKey")
        except Exception:
            pass
        er = {"err": "pubkey"}
        if pk:
            try:
                from Crypto.PublicKey import RSA
                from Crypto.Cipher import PKCS1_v1_5
                der = base64.b64decode(pk.replace("\\n", ""))
                pub = RSA.import_key(der)
                ts = int(time.time())
                plain = f"{email}||{cfg('ACCOUNT_PASS')}{ts}"
                enc = base64.b64encode(PKCS1_v1_5.new(pub).encrypt(plain.encode())).decode()
                payload = {"username": uname, "email": email, "password": enc,
                           "source": "", "clientId": ""}
                er = page.evaluate("""async (body) => {
                    const r = await fetch('/gw/uaa-be/api/v1/register/byEmail', {
                        method: 'POST', headers: {'Content-Type': 'application/json'},
                        credentials: 'include', body: JSON.stringify(body)
                    });
                    const t = await r.text();
                    return {status: r.status, ct: r.headers.get('content-type') || '',
                            len: t.length, head: t.slice(0, 700)};
                }""", payload)
            except Exception as e:
                er = {"err": str(e)[:60]}
        browser.close()
        h = er.get("head", "") or ""
        if er.get("err"):
            return "ERROR", None, ip, er["err"]
        if "html" in er.get("ct", "") or h.lstrip().startswith("<"):
            return ("BLOCK405" if er.get("len", 9999) < 5000 else "CHALLENGE"), None, ip, h[:80]
        if er.get("status") == 429 or "Too many" in h:
            return "APP429", None, ip, ""
        try:
            j = json.loads(h)
        except Exception:
            return "WEIRD", {"raw": h[:300]}, ip, h[:80]
        if j.get("success") and j.get("data", {}).get("ssoUid"):
            return "BIZ_OK", j, ip, ""
        return "BIZ_ERR", j, ip, ""


def phase_register(count=None, start_idx=None):
    from playwright.sync_api import sync_playwright  # noqa: import check
    ensure_dirs()
    n = int(count or cfg("COUNT") or "45")
    base_idx = int(start_idx or cfg("START_IDX") or "1011")

    def rand_ses():
        return "ses" + "".join(random.choices(string.ascii_letters + "0123456789", k=6))

    accs = load_accounts()
    done = {a["email"] for a in accs}
    results = []
    for i in range(1, n + 1):
        idx = base_idx + i
        email = email_for(idx)
        uname = uname_for(idx)
        if email in done:
            log(f"--- {i}/{n} {email} SKIP (sudah ada)")
            continue
        log(f"--- {i}/{n} email={email}")
        ok = False
        for a in range(6):
            cls, j, ip, note = register_attempt(rand_ses(), email, uname)
            log(f"    a{a}: cls={cls} ip={ip} {note[:60]}")
            if cls == "BIZ_OK":
                log(f"      OK ssoUid={j['data']['ssoUid']}")
                rec = {"email": email, "uname": uname, "ssoUid": j["data"]["ssoUid"],
                       "server_email": j["data"].get("email"), "password": cfg("ACCOUNT_PASS"),
                       "ts": time.time()}
                results.append(rec)
                accs.append(rec)
                save_accounts(accs)
                ok = True
                break
            if cls in ("BIZ_ERR", "ERROR", "CHALLENGE"):
                log(f"      reach app: {str(j)[:100]}")
                ok = True  # account terdaftar atau sudah masuk app
                break
            time.sleep(1)
        if not ok:
            log("    !! fail setelah retry")
        time.sleep(1)
    log(f"=== REGISTER DONE: {len(results)} baru | total ledger: {len(accs)} ===")
    return len(results)


# ============================================================
# Fase 2: SCAN IMAP (link aktivasi)
# ============================================================
def phase_scan():
    ensure_dirs()
    GU, GP = cfg("GMAIL_USER"), cfg("GMAIL_PASS")
    host = cfg("GMAIL_IMAP_HOST", "imap.gmail.com")
    port = int(cfg("GMAIL_IMAP_PORT", "993"))
    if not GU or not GP:
        sys.exit("[!] GMAIL_USER/GMAIL_PASS kosong di config.env")
    M = imaplib.IMAP4_SSL(host, port)
    M.login(GU, GP)
    M.select("INBOX")
    typ, data = M.search(None, "FROM", '"dm.openxlab.org.cn"')
    ids = data[0].split()
    log(f"total email aktivasi di inbox: {len(ids)}")
    found = {}
    for id_ in ids:
        typ, msgdata = M.fetch(id_, "(RFC822)")
        msg = email.message_from_bytes(msgdata[0][1])
        to = msg.get("To", "")
        date = msg.get("Date", "")
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() in ("text/plain", "text/html"):
                    b = part.get_payload(decode=True)
                    if b:
                        body += b.decode("utf-8", errors="ignore")
        else:
            b = msg.get_payload(decode=True)
            if b:
                body = b.decode("utf-8", errors="ignore")
        m = re.search(r"active\?token=([A-Za-z0-9]+)&sign=([A-Za-z0-9]+)", body)
        emails = re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", to)
        if m:
            for e in emails:
                local, dom = e.split("@")
                for k in (local + "@" + dom.lower(), local.replace(".", "") + "@" + dom.lower()):
                    if k not in found:
                        found[k] = {"token": m.group(1), "sign": m.group(2),
                                    "date": date, "raw_to": to}
    M.logout()
    json.dump(found, open(ACTMAP_JSON, "w"), indent=1)
    log(f"token unik: {len(found)} -> {ACTMAP_JSON}")
    return len(found)


# ============================================================
# Fase 3: ACTIVATE (POST register/active, retry proxy beda)
# ============================================================
def fetch_activation_links():
    GU, GP = cfg("GMAIL_USER"), cfg("GMAIL_PASS")
    host = cfg("GMAIL_IMAP_HOST", "imap.gmail.com")
    port = int(cfg("GMAIL_IMAP_PORT", "993"))
    M = imaplib.IMAP4_SSL(host, port)
    M.login(GU, GP)
    M.select("INBOX")
    typ, data = M.search(None, '(FROM "dm.openxlab.org.cn")')
    out = []
    for i in data[0].split():
        i = i.decode()
        typ, msg_data = M.fetch(i, "(RFC822)")
        msg = email.message_from_bytes(msg_data[0][1])
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/html":
                    body = part.get_payload(decode=True).decode("utf-8", "ignore")
                    break
        else:
            body = (msg.get_payload(decode=True) or b"").decode("utf-8", "ignore")
        m = re.search(r"https://sso\.openxlab\.org\.cn/active\?token=([^&\s\"<>]+)&sign=([^&\s\"<>]+)", body)
        if m:
            out.append({"token": m.group(1), "sign": m.group(2), "date": msg["Date"], "msg_id": i})
    M.logout()
    return out


def dt_key(a):
    try:
        parts = a["date"].split()
        hm = parts[4].split(":")
        return int(hm[0]) * 3600 + int(hm[1]) * 60 + int(hm[2])
    except Exception:
        return 0


def activate_one(a, attempt):
    import requests
    url = cfg("SSO_BASE") + "/gw/uaa-be/api/v1/register/active"
    payload = {"sign": a["sign"], "token": a["token"]}
    proxy_url = f"http://{cfg('PROXY_USER')}__sid.act{attempt}:{cfg('PROXY_PASS')}@{cfg('PROXY_HOST')}:{cfg('PROXY_PORT')}"
    headers = {
        "Content-Type": "application/json",
        "Origin": cfg("SSO_BASE"),
        "Referer": cfg("SSO_BASE") + "/active",
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
    }
    try:
        r = requests.post(url, json=payload, headers=headers,
                          proxies={"http": proxy_url, "https": proxy_url}, timeout=25)
        return r.text
    except Exception as e:
        return f"ERR {str(e)[:40]}"


def phase_activate():
    ensure_dirs()
    st = {}
    if os.path.exists(ACTIVATED_JSON):
        try:
            st = json.load(open(ACTIVATED_JSON))
        except Exception:
            st = {}
    links = fetch_activation_links()
    links_sorted = sorted(links, key=dt_key, reverse=True)
    log(f"[+] {len(links)} link aktivasi ditemukan")
    lock = threading.Lock()
    counters = {"ok": 0, "skip": 0, "fail": 0}
    todo = [a for a in links_sorted if st.get(a["token"]) != "OK"]

    def _do(a):
        for attempt in range(1, 4):
            res = activate_one(a, attempt + int(time.time()) % 7)
            if '"success":true' in res or "A0226" in res or "already" in res.lower():
                return a, "OK", res
            if "A0227" in res or "expired" in res.lower():
                return a, "EXPIRED", res
            time.sleep(0.8)
        return a, "FAIL", res

    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(_do, a): a for a in todo}
        for i, f in enumerate(as_completed(futs), 1):
            a, result, res = f.result()
            with lock:
                if result == "OK":
                    counters["ok"] += 1
                    st[a["token"]] = "OK"
                    log(f"  OK {a['token'][:12]} ACTIVE")
                elif result == "EXPIRED":
                    st[a["token"]] = "EXPIRED"
                    counters["fail"] += 1
                    log(f"  EXPIRED {a['token'][:12]}")
                else:
                    counters["fail"] += 1
                    log(f"  FAIL {a['token'][:12]} res={res[:70]}")
                if i % 20 == 0:
                    json.dump(st, open(ACTIVATED_JSON, "w"), indent=1)
    counters["skip"] = len(links_sorted) - len(todo)
    json.dump(st, open(ACTIVATED_JSON, "w"), indent=1)
    log(f"[=] ACTIVATE done: {counters['ok']} ok, {counters['skip']} skip, {counters['fail']} fail/expired")
    return counters["ok"]


# ============================================================
# Fase 4: LOGIN + CREATE KEY (BrowserSession reuse + DiscoveryClient)
# ============================================================
def worker_login(args):
    email, pwd, uname = args
    sys.path.insert(0, LIB)
    os.chdir(LIB)
    if cfg("CHROME_PATH"):
        os.environ["IR_CHROME_PATH"] = cfg("CHROME_PATH")

    from src.browser.session import BrowserSession
    from src.browser.settings import BrowserSettings
    from src.discovery import DiscoveryClient
    from common import config

    last = "no_attempt"
    for attempt in range(4):
        sid = "ses" + "".join(random.choices(string.ascii_letters + "0123456789", k=6))
        os.environ["IR_LOGIN_PROXY"] = (f"{cfg('PROXY_HOST')}|{cfg('PROXY_PORT')}|"
                                        f"{cfg('PROXY_USER')}__sid.{sid}|{cfg('PROXY_PASS')}")
        try:
            settings = BrowserSettings.from_config(config)
            with BrowserSession(headless=True, settings=settings) as sess:
                res = sess.login(email, pwd, verbose=False, timeout=70, attempts=1, cooldown=1)
                if not res.jwt:
                    last = f"sid={sid} fail: {res.reason[:90]}"
                    log(f"  {uname} a{attempt}: {last[:110]}")
                    continue
                dc = DiscoveryClient(jwt=res.jwt, cookies=res.cookies)
                name = f"9r-{uname}-{int(time.time()) % 100000}"
                ak = dc.create_key(name)
                key = ak.key if hasattr(ak, "key") else str(ak)
                out = os.path.join(KEYS, f"probe_{uname}.json")
                json.dump({"email": email, "tag": uname, "password": pwd,
                           "status": "ok", "key": key, "sid": sid}, open(out, "w"),
                          ensure_ascii=False)
                log(f"OK {uname} key={key[:10]} sid={sid}")
                return {"email": email, "tag": uname, "password": pwd, "status": "ok", "key": key}
        except Exception as e:
            last = f"sid={sid} ERR {str(e)[:110]}"
            log(f"  {uname} a{attempt}: {last[:110]}")
        time.sleep(3)
    log(f"LOGIN_FAIL {uname}: {last}")
    return {"email": email, "tag": uname, "password": pwd, "status": "fail", "err": last}


def phase_login(count=None):
    ensure_dirs()
    accs = load_accounts()
    if not accs:
        sys.exit("[!] state/accounts.json kosong — jalankan --register dulu")
    if count:
        accs = accs[: int(count)]

    # resume: skip yang sudah ok di keys.jsonl
    ok_tags = set()
    if os.path.exists(KEYS_JSONL):
        for ln in open(KEYS_JSONL):
            try:
                r = json.loads(ln)
                if r.get("status") == "ok":
                    ok_tags.add(r.get("tag"))
            except Exception:
                pass
    for fp in glob.glob(os.path.join(KEYS, "probe_*.json")):
        try:
            r = json.load(open(fp))
            if r.get("status") == "ok":
                ok_tags.add(r.get("tag"))
        except Exception:
            pass

    queue = [a for a in accs if (a.get("uname") or a["email"].split("@")[0]) not in ok_tags]
    log(f"LOGIN queue: {len(queue)} | sudah ok: {len(ok_tags)}")

    n_ok = n_fail = 0
    lock = threading.Lock()
    with ThreadPoolExecutor(max_workers=3) as ex:
        futs = {ex.submit(worker_login, (a["email"], a["password"],
                                         a.get("uname") or a["email"].split("@")[0])): a for a in queue}
        for i, f in enumerate(as_completed(futs), 1):
            r = f.result()
            n_ok += r["status"] == "ok"
            n_fail += r["status"] != "ok"
            log(f"[{i}/{len(queue)}] {r['email']} -> {r['status']}")
            with lock:
                with open(KEYS_JSONL, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    log(f"LOGIN DONE ok={n_ok} fail={n_fail}")
    return n_ok


# ============================================================
# Fase 5: INSERT ke 9router
# Cara utama: HTTP API (ROUTER_URL + ROUTER_PASS) — login dapat cookie auth_token,
#             lalu POST /api/providers buat connection.
# Cara fallback opsional: sqlite langsung (ROUTER_DB) jika 9router di mesin yang sama.
# ============================================================
def _router_forge_jwt(secret):
    """Buat cookie auth_token sendiri dari JWT-secret 9router (HS256, 24h).
    Berfungsi jika 9router pakai jwt-secret default/ini di ~/.9router/jwt-secret."""
    def b64(d):
        return base64.urlsafe_b64encode(json.dumps(d, separators=(",", ":")).encode()).rstrip(b"=").decode()
    hdr = b64({"alg": "HS256", "typ": "JWT"})
    now = int(time.time())
    pl = b64({"authenticated": True, "iat": now, "exp": now + 86000})
    sig = base64.urlsafe_b64encode(hmac.new(secret.encode(), f"{hdr}.{pl}".encode(), hashlib.sha256).digest()).rstrip(b"=").decode()
    return f"{hdr}.{pl}.{sig}"


def _router_http(method, url, cookie=None, body=None, timeout=20):
    """HTTP helper stdlib (urllib) untuk API 9router. Return (status, data, err, headers)."""
    headers = {"Content-Type": "application/json"}
    if cookie:
        headers["Cookie"] = f"auth_token={cookie}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            try:
                return r.status, json.loads(raw), None, r.headers
            except Exception:
                return r.status, raw.decode("utf-8", "replace"), None, r.headers
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read()), None, e.headers
        except Exception:
            return e.code, None, None, e.headers
    except Exception as e:
        return None, None, e, None


def _router_api_login(base, password):
    """POST /api/auth/login {password} -> cookie auth_token (JWT HS256 24h)."""
    status, data, err, headers = _router_http("POST", base.rstrip("/") + "/api/auth/login", body={"password": password})
    if status == 429:
        raise SystemExit("[!] 9router lockout — terlalu banyak password salah. Tunggu / ganti password.")
    if status != 200:
        raise SystemExit(f"[!] login 9router gagal HTTP {status}: {str(data)[:150]}")
    cookie = None
    if headers:
        sc = headers.get("Set-Cookie", "")
        if "auth_token=" in sc:
            cookie = sc.split("auth_token=")[1].split(";")[0]
    if not cookie:
        raise SystemExit("[!] login 9router sukses tapi cookie auth_token tidak ditemukan")
    return cookie


def _router_api_create(base, cookie, node, name, apikey):
    """POST /api/providers -> 201. Return (ok, pesan)."""
    status, data, err, _h = _router_http("POST", base.rstrip("/") + "/api/providers",
                                         cookie=cookie, body={"provider": node, "apiKey": apikey, "name": name})
    if err:
        return False, f"network: {err}"
    if status == 201:
        return True, "created"
    if status == 409:
        return False, "exists"
    return False, f"HTTP {status}: {str(data)[:150]}"


def _router_api_list_names(base, cookie, node):
    """GET /api/providers -> set nama connection yang sudah ada untuk node ini."""
    status, data, err, _h = _router_http("GET", base.rstrip("/") + "/api/providers", cookie=cookie)
    if status != 200 or not isinstance(data, dict):
        return None
    return {c.get("name") for c in data.get("connections", []) if c.get("provider") == node}


def phase_insert():
    ensure_dirs()
    node = cfg("ROUTER_NODE")
    prefix = cfg("ROUTER_PREFIX", "ink")
    base_url = cfg("ROUTER_BASEURL")
    router_url = cfg("ROUTER_URL")
    router_pass = cfg("ROUTER_PASS")
    if not node or not base_url:
        sys.exit("[!] ROUTER_NODE / ROUTER_BASEURL kosong di config.env")

    keys = {}

    def add(tag, key):
        # strip prefix TAG (inkr) — hasil tag bersih: 966x, 1501x, dst.
        # ⚠️ jangan strip ROUTER_PREFIX (ink) — itu prefix node 9router, bukan tag akun
        tag = tag.replace(cfg("TAG_PREFIX", "inkr"), "").strip()
        if tag and key and tag not in keys:
            keys[tag] = key

    if os.path.exists(KEYS_JSONL):
        for ln in open(KEYS_JSONL):
            try:
                r = json.loads(ln)
                if r.get("status") == "ok" and r.get("key"):
                    add(r.get("tag") or r["email"].split("@")[0], r["key"])
            except Exception:
                pass
    for fp in glob.glob(os.path.join(KEYS, "probe_*.json")):
        try:
            r = json.load(open(fp))
            if r.get("status") == "ok" and r.get("key"):
                add(r.get("tag") or os.path.basename(fp).replace("probe_", "").replace(".json", ""), r["key"])
        except Exception:
            pass

    log(f"kumpul unique keys: {len(keys)}")
    if not keys:
        log("tidak ada key — jalankan --login dulu")
        return 0

    # ---- MODE HTTP API (utama) ----
    router_secret = cfg("ROUTER_JWT_SECRET")
    if router_url and (router_secret or router_pass):
        log(f"mode HTTP API: {router_url}")
        if router_secret:
            cookie = _router_forge_jwt(router_secret)
            log("auth: JWT-secret (forge auth_token, tanpa login)")
        else:
            cookie = _router_api_login(router_url, router_pass)
            log("login 9router OK (cookie auth_token didapat)")
        existing = _router_api_list_names(router_url, cookie, node)
        if existing is None:
            existing = set()
            log("[!] GET /api/providers gagal — skip pengecekan duplikat")
        inserted = 0
        for tag, key in sorted(keys.items()):
            name = f"intern-{tag}"
            if name in existing:
                continue
            ok, pesan = _router_api_create(router_url, cookie, node, name, key)
            if ok:
                inserted += 1
                log(f"  + {name}: created")
            elif pesan == "exists":
                pass
            else:
                log(f"  ! {name}: {pesan}")
        total = len(existing) + inserted
        log(f"INSERTED: {inserted} | TOTAL CONN {node}: ~{total}")
        return inserted

    # ---- MODE SQLITE (fallback): butuh akses file data.sqlite ----
    db_path = cfg("ROUTER_DB")
    if not db_path:
        sys.exit("[!] 9router belum dikonfigurasi — isi ROUTER_URL+ROUTER_PASS (HTTP API, rekomendasi) atau ROUTER_DB (path sqlite, hanya jika 9router di mesin yang sama)")
    if not os.path.exists(db_path):
        sys.exit(f"[!] ROUTER_DB tidak ketemu: {db_path}")

    def conn_json(apikey):
        return json.dumps({
            "apiKey": apikey,
            "testStatus": "unavailable",
            "providerSpecificData": {
                "prefix": prefix, "apiType": cfg("ROUTER_API_TYPE", "chat"),
                "baseUrl": base_url, "nodeName": cfg("ROUTER_NODENAME", "intern"),
                "connectionProxyEnabled": False, "connectionProxyUrl": "", "connectionNoProxy": "",
            },
            "errorCode": None, "backoffLevel": 0, "modelLock_intern-s2": None,
        }, ensure_ascii=False)

    ts_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    db = sqlite3.connect(db_path)
    cur = db.cursor()
    cur.execute("SELECT name FROM providerConnections WHERE provider=?", (node,))
    existing = {r[0] for r in cur.fetchall()}
    inserted = 0
    for tag, key in sorted(keys.items()):
        name = f"intern-{tag}"
        if name in existing:
            continue
        cur.execute(
            "INSERT INTO providerConnections (id, provider, authType, name, email, priority, isActive, data, createdAt, updatedAt) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (f"{prefix}-{tag}-{int(datetime.now(timezone.utc).timestamp())}", node, "apikey",
             name, None, 1, 1, conn_json(key), ts_utc, ts_utc),
        )
        inserted += 1
    db.commit()
    cur.execute("SELECT COUNT(*) FROM providerConnections WHERE provider=? AND isActive=1", (node,))
    total = cur.fetchone()[0]
    db.close()
    log(f"INSERTED: {inserted} | TOTAL CONN {node}: {total}")
    return inserted


# ============================================================
# STATUS
# ============================================================
def phase_status():
    load_config()
    print("=== INTERN FARM — status config ===")
    show = [
        ("GMAIL_USER", cfg("GMAIL_USER")),
        ("GMAIL_PASS", mask(cfg("GMAIL_PASS"))),
        ("EMAIL_BASE", cfg("EMAIL_BASE")),
        ("EMAIL_DOMAIN", cfg("EMAIL_DOMAIN")),
        ("TAG_PREFIX", cfg("TAG_PREFIX")),
        ("START_IDX", cfg("START_IDX")),
        ("COUNT", cfg("COUNT")),
        ("PROXY", f"{cfg('PROXY_HOST')}:{cfg('PROXY_PORT')} user={mask(cfg('PROXY_USER'))}"),
        ("SSO_BASE", cfg("SSO_BASE")),
        ("DISCOVERY_API", cfg("DISCOVERY_API")),
        ("CHAT_API_BASE", cfg("CHAT_API_BASE")),
        ("CHROME_PATH", cfg("CHROME_PATH") or "(default)"),
        ("ROUTER_URL", cfg("ROUTER_URL") or "(kosong)"),
        ("ROUTER_PASS", mask(cfg("ROUTER_PASS")) if cfg("ROUTER_PASS") else "(kosong)"),
        ("ROUTER_JWT_SECRET", mask(cfg("ROUTER_JWT_SECRET")) if cfg("ROUTER_JWT_SECRET") else "(kosong)"),
        ("ROUTER_DB", cfg("ROUTER_DB") or "(kosong)"),
        ("ROUTER_NODE", cfg("ROUTER_NODE")),
    ]
    for k, v in show:
        print(f"  {k:14} {v}")
    print("=== Dependensi ===")
    for pkg in ["requests", "cryptography", "playwright", "Crypto"]:
        try:
            mod = __import__(pkg)
            ver = getattr(mod, "__version__", "ok")
            print(f"  {pkg:14} OK ({ver})")
        except Exception:
            print(f"  {pkg:14} MISSING — pip install -r requirements.txt")
    if os.path.exists(ACCOUNTS_JSON):
        print(f"=== Ledger akun: {len(load_accounts())} ===")
    else:
        print("=== Ledger akun: belum ada (jalankan --register) ===")


# ============================================================
# MAIN
# ============================================================
def main():
    ap = argparse.ArgumentParser(description="Intern Farm portable (5 fase)")
    ap.add_argument("--status", action="store_true", help="cek config + dependensi")
    ap.add_argument("--register", action="store_true", help="fase 1: register akun")
    ap.add_argument("--scan", action="store_true", help="fase 2: scan IMAP link aktivasi")
    ap.add_argument("--activate", action="store_true", help="fase 3: aktivasi akun")
    ap.add_argument("--login", action="store_true", help="fase 4: login + create API key")
    ap.add_argument("--insert", action="store_true", help="fase 5: insert key ke 9router")
    ap.add_argument("--all", action="store_true", help="jalankan semua fase berurutan")
    ap.add_argument("--count", type=int, default=None, help="jumlah akun (override config)")
    ap.add_argument("--start", type=int, default=None, help="index awal (override config)")
    args = ap.parse_args()

    load_config()
    if args.status:
        phase_status()
        return
    if not (args.register or args.scan or args.activate or args.login or args.insert or args.all):
        ap.print_help()
        return

    if args.register or args.all:
        phase_register(args.count, args.start)
    if args.scan or args.all:
        phase_scan()
    if args.activate or args.all:
        phase_activate()
    if args.login or args.all:
        phase_login(args.count)
    if args.insert or args.all:
        phase_insert()


if __name__ == "__main__":
    main()