# Intern Farm — Toolchain Farming API Key OpenXLab/Intern (Portable)

Toolchain lengkap farming API key Intern (OpenXLab SSO → Discovery → API Key → 9router).
**Cara kerja sama persis pipeline yang berhasil jebol 45+ akun** (15-16 Okt 2026).
Bisa jalan di **Windows maupun Linux**, semua pengaturan dipisah di `config.env`.

```
intern-farm-portable/
├── farm.py            # Satu file: 5 fase farming (register→scan→activate→login→insert)
├── config.env         # ★ SEMUA pengaturan: email, proxy, target, chrome, 9router
├── requirements.txt   # pip install -r requirements.txt
├── README.md
├── lib/               # library vendor (common/ + src/ dari Intern-Register-Tool)
│   ├── common/
│   └── src/
├── state/             # ledger akun, map aktivasi, state (dibuat otomatis)
├── keys/              # hasil API key per akun (dibuat otomatis)
└── logs/              # farm.log (dibuat otomatis)
```

## Setup (sekali)

```bash
# 1. Python 3.10+
python --version

# 2. Install dependensi
pip install -r requirements.txt
playwright install chromium          # atau pakai Chrome yang sudah ada, set CHROME_PATH

# 3. Edit config.env — isi bagian yang masih kosong:
#    GMAIL_USER / GMAIL_PASS   (IMAP app password, penerima email aktivasi)
#    PROXY_USER / PROXY_PASS   (proxy auth; support DataImpulse sid-rotate)
#    ROUTER_URL                (alamat 9router, mis. http://192.168.12.102:20128)
#    ROUTER_PASS               (password web-admin 9router)
#    (opsional) ROUTER_JWT_SECRET (JWT-secret 9router utk forge token, tanpa login)
#    (fallback) ROUTER_DB      (path data.sqlite, hanya utk mesin yang sama)
```
Insert ke 9router sekarang via **HTTP API** (cukup alamat + password, tidak perlu
akses file DB). `ROUTER_URL`+`ROUTER_PASS` atau `ROUTER_URL`+`ROUTER_JWT_SECRET`
— salah satu. `ROUTER_DB` hanya fallback bila 9router jalan di mesin yang sama.

## Cara pakai

```bash
python farm.py --status              # cek config + dependensi (nilai sensitif di-mask)

# Jalankan per fase (bioar bisa resume & debug):
python farm.py --register             # 1. buat akun (Playwright + RSA + proxy rotate)
python farm.py --scan                 # 2. scan IMAP cari link aktivasi
python farm.py --activate             # 3. aktivasi massal via HTTP POST
python farm.py --login                # 4. login + create API key (paralel 3)
python farm.py --insert               # 5. insert key ke 9router (auto-skip dup)

# Atau sekali jalan:
python farm.py --all --count 45 --start 1011
```

Argumen opsional: `--count N` (jumlah akun, override config), `--start IDX` (index awal).

## Alur kerja (kenapa persis yang jebol)

1. **register** — Playwright headless + proxy DataImpulse sid-rotate (tiap percobaan IP beda),
   RSA encrypt `email||pass+unix_detik` (detik, BUKAN ms), POST `/register/byEmail`.
   Hanya akun **fresh** yang dihitung; dup/sudah ada di-skip via state/accounts.json.
2. **scan** — Baca IMAP, cari email dari `dm.openxlab.org.cn`, regex
   `active?token=...&sign=...` → simpan map token↔email.
3. **activate** — POST `/register/active` `{sign, token}` via curl/requests + proxy, retry 3x
   proxy beda. Idempotent via state/activated.json. (Kunci: akun yang belum aktivasi
   akan ditolak login dengan A0212 — bukan captcha.)
4. **login+key** — `BrowserSession` (reuse 1 browser, ganti context per akun) + `DiscoveryClient`
   create_key. Paralel 3 akun, timeout 70s per percobaan, max 4 percobaan/akun, proxy rotate
   tiap percobaan.
5. **insert** — Insert `providerConnections` ke 9router `data.sqlite`.
   `providerSpecificData` WAJIB lengkap (`{prefix, apiType, baseUrl, nodeName}`) — kalau
   kosong 9router fallback ke api.openai.com → 401. Auto-skip nama yang sudah ada.

## Catatan penting

- **Aktivasi email delay ±45 menit** setelah register. Link sekali pakai, masa aktif ±2 jam.
- **Jangan ubah `lib/`** — itu vendor dari Intern-Register-Tool (patched: IR_LOGIN_PROXY,
  IR_DEBUG_RESP). Kalau pipeline berubah, update `lib/` dari repo asli.
- **9router**: fase insert harus jalan di mesin yang punya akses `data.sqlite` 9router.
  Bisa dijalankan mesin terpisah via network path, atau jalankan hanya fase insert di server.
- **Rate limit**: register punya kuota kumulatif (±40 akun per window, B0000). Terkena?
  Berhenti, tunggu (lama), atau pakai email domain lain / proxy beda.
- **Ink/kuota**: tidak ada endpoint balance (404). Ukuran kapasitas = rate limit per key
  dari `GET /v1/models` (intern-s2 ≈ 5 miliar prompt tok/min/key; model 0-ink gratis:
  intern-s2, Atria-Dawn-Preview, Atria-Dawn).

## Status 2026-10-16

53 koneksi `ink/*` aktif di 9router (node intern). Cetak salinan paket ini:
```bash
# zip ke file biar gampang dipindah
cd ~ && zip -r intern-farm-portable.zip intern-farm-portable
```