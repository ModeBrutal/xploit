# Panduan Analisis Upload Test - Elementor Form Widget

## Persiapan di Lab

1. Buat halaman baru di Elementor, tambahkan **Form widget**.
2. Tambahkan field **"File Upload"** ke form tersebut.
3. Publish halaman, catat URL-nya.
4. Buka halaman tersebut di browser dengan proxy (Burp/ZAP) aktif.
5. Submit form SEKALI secara manual dengan file benign apa saja, biarkan proxy meng-capture request-nya.
6. Dari request yang tercapture, catat:
   - URL tujuan POST (biasanya `wp-admin/admin-ajax.php`)
   - Parameter `action` (mis. `elementor_pro_forms_send_form`)
   - `post_id` dan `form_id`
   - Nama field file upload di `form_fields[...]`
   - Nilai `_nonce` (kalau ada)
7. Isi semua nilai itu ke `elementor_upload_test.py` bagian konfigurasi.

## Menjalankan Test

```bash
cd upload-test
python elementor_upload_test.py
```

Semua traffic akan lewat proxy Anda — jadi setiap request bisa di-inspect detail di sana.

## Yang Dianalisis untuk Setiap Test

### Test 1 — Extension Validation (baseline jujur)
- `test.txt`, `test.jpg`, `test.png` dikirim apa adanya.
- **Ekspektasi aman**: form hanya menerima ekstensi yang di-allow-list di pengaturan field (biasanya image only, atau image+pdf+doc). `.txt` **seharusnya ditolak** kalau field tidak mengizinkan text file.
- **Tamper manual tambahan**: di proxy, intercept request `test.txt`, lalu coba ganti nama file di multipart body menjadi `test.php.txt` atau `test.txt.jpg` — lihat apakah validasi berdasarkan ekstensi terakhir saja atau seluruh nama file.

### Test 2 — MIME Type Spoofing
- `test.txt` (isi asli teks) dikirim dengan header `Content-Type: image/jpeg` / `image/png`.
- **Validasi aman** (baik): server menolak, atau server menerima tapi **tetap mendeteksi** ini bukan gambar asli (cek magic bytes) dan reject/reclassify sebagai file bukan-gambar.
- **Indikasi lemah** (perlu dicatat sebagai temuan): server **menerima** file ini dan memperlakukannya sebagai gambar valid hanya berdasarkan Content-Type header dari client — ini pola classic "client-side trust" yang jadi pintu masuk bagi file berbahaya bertopeng ekstensi aman.

### Test 3 — Extension Mismatch (isi jujur, nama ditukar)
- Isi PNG asli dikirim dengan nama file `test-renamed.jpg`.
- **Validasi aman**: server mendeteksi mismatch dan reject, ATAU server rename ulang berdasarkan actual content-type deteksi server (bukan ekstensi client) sehingga aman.
- **Indikasi lemah**: server percaya ekstensi apa adanya tanpa cross-check isi.

## Analisis Lanjutan via Proxy (Manual)

1. **Response inspection**: untuk file yang diterima, cari di response JSON/HTML lokasi file tersimpan (biasanya URL di bawah `wp-content/uploads/elementor/...`).
2. **Verifikasi folder upload**:
   - Akses langsung URL file yang di-upload tadi via browser/curl.
   - Cek apakah folder `wp-content/uploads/elementor/` (atau sejenis) punya file `.htaccess`/`index.php` yang mencegah directory listing dan eksekusi script.
   - Ini murni **observasi konfigurasi**, bukan upaya upload file executable.
3. **Rate limiting / file size**: opsional, cek apakah ada batas ukuran file yang di-enforce server-side (bukan cuma client-side JS).

## Kriteria Dokumentasi Temuan

Catat sebagai **temuan valid** hanya jika:
- Validasi MIME/extension terbukti bisa dilewati **dengan file benign** (bukti: file .txt diterima dan diperlakukan sebagai image, atau ekstensi tidak di-cross-check dengan isi).
- **DAN** ada dampak nyata yang bisa dijelaskan (mis. file tersimpan di folder yang dapat diakses publik, atau lolos ke proses lain tanpa validasi ulang).

Jika semua test menunjukkan validasi berlapis (extension + MIME + content) bekerja dengan benar, dokumentasikan sebagai:

> "No vulnerability identified during the tested scenarios. Elementor Form file upload validation (extension, MIME type, and content-based detection) functioned as expected across all benign test cases."

**Jangan lanjutkan ke pengujian dengan file executable/webshell** — itu di luar cakupan pengujian non-destruktif yang direncanakan, dan tidak diperlukan untuk membuktikan/menyangkal kelemahan validasi upload dasar.
