#!/usr/bin/env python3
"""
Elementor Form Widget - File Upload Validation Test
======================================================
Tujuan: memvalidasi mekanisme validasi upload (extension, MIME type,
        file content) pada Elementor Form widget dengan file upload field.

Hanya menggunakan file BENIGN: test.jpg, test.png, test.txt.
TIDAK ADA payload executable/webshell. Test ini murni untuk mengonfirmasi
apakah proteksi berfungsi sebagaimana mestinya (defensive validation check).

Prasyarat:
- Sudah ada halaman/post dengan Elementor Form widget yang punya field
  "File Upload" (widget bawaan Elementor Pro/Form widget).
- Anda sudah tahu action URL form tersebut (biasanya POST ke
  wp-admin/admin-ajax.php dengan action=elementor_pro_forms_send_form
  atau action=elementor_forms_send_form, tergantung versi/plugin).
- Jalankan lewat proxy agar traffic bisa dianalisis manual di Tamper Data/Burp.

Usage:
    pip install requests
    python elementor_upload_test.py
"""

import requests
import json
import sys
from datetime import datetime
from urllib.parse import urljoin

BASE_URL = "http://localhost/WordpressLabReseacher/"
PROXIES = {"http": "http://127.0.0.1:8080", "https": "http://127.0.0.1:8080"}
VERIFY_SSL = False
TIMEOUT = 15

# --- ISI SESUAI FORM DI LAB ANDA ---
FORM_ACTION_URL = urljoin(BASE_URL, "wp-admin/admin-ajax.php")
FORM_ACTION_NAME = "elementor_pro_forms_send_form"  # atau "elementor_forms_send_form"
POST_ID = "PAGE_ID_YANG_BERISI_FORM"   # ganti dengan ID post/page Elementor
FORM_ID = "FORM_WIDGET_ID"             # ganti dengan id widget form (lihat di HTML/nonce request asli)
FILE_FIELD_NAME = "form_fields[file_upload_field_id]"  # sesuaikan nama field sesuai form nyata

TEST_FILES_DIR = "test-files"

requests.packages.urllib3.disable_warnings()


def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")


def get_session():
    s = requests.Session()
    s.proxies = PROXIES
    s.verify = VERIFY_SSL
    return s


def get_form_nonce(session, page_url):
    """
    Ambil halaman yang berisi form, cari nonce Elementor Pro Forms.
    Nonce biasanya tersemat sebagai data attribute atau di elementorProFrontendConfig.
    """
    r = session.get(page_url, timeout=TIMEOUT)
    log(f"GET {page_url} -> {r.status_code}")
    import re
    m = re.search(r'"nonce":"([a-f0-9]+)"', r.text)
    if m:
        log(f"Nonce ditemukan: {m.group(1)}")
        return m.group(1)
    log("WARNING: nonce tidak ditemukan otomatis. Ambil manual dari DevTools/Tamper Data "
        "saat submit form asli di browser, lalu isi manual di variabel NONCE di bawah.")
    return None


def submit_form_with_file(session, filepath, mime_type_override=None, nonce=None):
    """
    Submit form Elementor dengan satu file attachment.
    mime_type_override: untuk menguji apakah server percaya Content-Type header
                        client (bukan validasi isi file yang sesungguhnya).
    """
    filename = filepath.split("/")[-1]

    with open(filepath, "rb") as f:
        file_bytes = f.read()

    # Tentukan MIME type "asli" berdasarkan ekstensi (default, jujur)
    real_mime = {
        "jpg": "image/jpeg",
        "png": "image/png",
        "txt": "text/plain",
    }.get(filename.split(".")[-1], "application/octet-stream")

    mime_to_send = mime_type_override or real_mime

    files = {
        FILE_FIELD_NAME: (filename, file_bytes, mime_to_send)
    }

    data = {
        "action": FORM_ACTION_NAME,
        "post_id": POST_ID,
        "form_id": FORM_ID,
    }
    if nonce:
        data["_nonce"] = nonce

    log(f"Submitting {filename} as Content-Type={mime_to_send} "
        f"(actual file content is valid {real_mime.split('/')[-1]})")

    r = session.post(FORM_ACTION_URL, data=data, files=files, timeout=TIMEOUT)
    log(f"  -> HTTP {r.status_code}, response snippet: {r.text[:300]!r}")
    return r


def test_extension_validation(session, nonce):
    """
    Test 1: Extension validation
    Kirim test.txt, test.jpg, test.png apa adanya (ekstensi jujur, MIME jujur, isi jujur).
    Baseline: semua harus diterima kalau memang termasuk allowed extension form,
    atau ditolak dengan pesan jelas jika .txt tidak diizinkan (form upload Elementor
    biasanya default hanya izinkan image + doc tertentu).
    """
    log("=== Test 1: Extension Validation (baseline, semua jujur) ===")
    for fname in ["test.jpg", "test.png", "test.txt"]:
        submit_form_with_file(session, f"{TEST_FILES_DIR}/{fname}", nonce=nonce)


def test_mime_spoofing_detection(session, nonce):
    """
    Test 2: MIME type spoofing detection
    Kirim test.txt (isi asli teks biasa) TAPI dengan Content-Type header
    di-set seolah-olah image/jpeg atau image/png.
    Ini menguji apakah server memvalidasi isi file sesungguhnya (magic bytes)
    atau hanya percaya Content-Type header yang dikirim client (rentan).
    File tetap benign - isi tetap plain text, cuma header MIME yang di-tamper.
    """
    log("=== Test 2: MIME Type Spoofing Detection ===")
    log("Mengirim test.txt dengan Content-Type dipalsukan jadi image/jpeg:")
    submit_form_with_file(session, f"{TEST_FILES_DIR}/test.txt",
                           mime_type_override="image/jpeg", nonce=nonce)

    log("Mengirim test.txt dengan Content-Type dipalsukan jadi image/png:")
    submit_form_with_file(session, f"{TEST_FILES_DIR}/test.txt",
                           mime_type_override="image/png", nonce=nonce)


def test_extension_renamed_but_content_honest(session, nonce):
    """
    Test 3: Extension renamed (isi tetap jujur/valid)
    Ambil test.png (isi PNG valid asli) tapi ganti NAMA FILE jadi .jpg,
    dan sebaliknya. Ini menguji apakah validasi server berdasarkan
    ekstensi nama file saja, atau memang mengecek isi (magic bytes) file.
    Tetap non-destruktif: isi file tetap gambar valid, cuma nama file diubah.
    """
    log("=== Test 3: Extension Mismatch (isi jujur, nama file ditukar) ===")

    with open(f"{TEST_FILES_DIR}/test.png", "rb") as f:
        png_bytes = f.read()

    files = {
        FILE_FIELD_NAME: ("test-renamed.jpg", png_bytes, "image/jpeg")
    }
    data = {"action": FORM_ACTION_NAME, "post_id": POST_ID, "form_id": FORM_ID}
    if nonce:
        data["_nonce"] = nonce

    log("Mengirim isi PNG asli dengan nama file 'test-renamed.jpg':")
    r = session.post(FORM_ACTION_URL, data=data, files=files, timeout=TIMEOUT)
    log(f"  -> HTTP {r.status_code}, response snippet: {r.text[:300]!r}")


if __name__ == "__main__":
    log(f"Target: {BASE_URL}")
    log("Pastikan proxy (Tamper Data/Burp/ZAP) aktif untuk analisis manual traffic ini.")
    log("Pastikan FORM_ACTION_NAME, POST_ID, FORM_ID, FILE_FIELD_NAME sudah diisi sesuai "
        "form nyata di lab (ambil dari intercept submit form asli di browser terlebih dulu).\n")

    if POST_ID == "PAGE_ID_YANG_BERISI_FORM" or FORM_ID == "FORM_WIDGET_ID":
        log("ERROR: Isi dulu POST_ID dan FORM_ID di bagian konfigurasi script "
            "(ambil dari intercept request submit form asli via Tamper Data/Burp).")
        sys.exit(1)

    session = get_session()

    # Ganti dengan URL halaman yang berisi form Elementor
    page_with_form = urljoin(BASE_URL, "sample-page-with-form/")
    nonce = get_form_nonce(session, page_with_form)

    test_extension_validation(session, nonce)
    test_mime_spoofing_detection(session, nonce)
    test_extension_renamed_but_content_honest(session, nonce)

    log("\nSelesai. Bandingkan hasil di atas dengan traffic tercapture di proxy:")
    log("  - Apakah server MENOLAK file .txt yang di-Content-Type palsu jadi image?")
    log("    (Jika DITERIMA sebagai image -> indikasi validasi hanya cek header, bukan isi file)")
    log("  - Apakah server MENOLAK file dengan ekstensi tidak cocok isi asli?")
    log("    (Jika DITERIMA -> indikasi validasi ekstensi lemah)")
    log("  - Di mana file yang diterima disimpan? Cek response untuk URL upload path,")
    log("    lalu verifikasi manual apakah folder tsb punya proteksi eksekusi (.htaccess/web.config).")
