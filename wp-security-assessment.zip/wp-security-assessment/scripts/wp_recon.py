#!/usr/bin/env python3
"""
WordPress + Plugin Security Assessment - Recon & Non-Destructive Testing
==========================================================================
Target   : http://localhost/WordpressLabReseacher/
Scope    : WordPress core, "visitors-traffic-real-time-statistics" (8.9.1),
           "elementor" (4.1.3), "elementor-pro" (unknown)
Method   : Black-box, non-destructive validation only.

CATATAN PENTING:
- Script ini TIDAK melakukan exploit destruktif (tidak ada DROP TABLE,
  tidak ada payload XSS yang benar-benar disimpan tanpa cleanup, tidak
  ada file upload berbahaya).
- Script ini HANYA boleh dijalankan terhadap target lab lokal Anda sendiri
  atau target yang eksplisit dalam scope pengujian yang diizinkan.
- Jalankan proxy (Burp/OWASP ZAP/Tamper Data equivalent) di 127.0.0.1:8080
  agar traffic script ini juga bisa diintercept dan dianalisis manual.

Usage:
    pip install requests
    python wp_recon.py
"""

import requests
import json
import sys
from datetime import datetime
from urllib.parse import urljoin

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------
BASE_URL = "http://localhost/WordpressLabReseacher/"
USE_PROXY = True  # set True agar traffic lewat Burp/ZAP/Tamper Data proxy
PROXIES = {"http": "http://127.0.0.1:8080", "https": "http://127.0.0.1:8080"} if USE_PROXY else None
VERIFY_SSL = False  # lab lokal biasanya http, tapi kalau https self-signed set False
TIMEOUT = 10

requests.packages.urllib3.disable_warnings()

session = requests.Session()
session.proxies = PROXIES
session.verify = VERIFY_SSL
session.headers.update({
    "User-Agent": "WP-SecurityAssessment-Lab/1.0 (authorized-internal-test)"
})

results = {
    "target": BASE_URL,
    "timestamp": datetime.now().isoformat(),
    "wordpress_core": {},
    "plugin_visitors_traffic": {},
    "plugin_elementor": {},
    "findings": []
}


def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")


def add_finding(title, detail, validated=False, severity="Info"):
    results["findings"].append({
        "title": title,
        "detail": detail,
        "validated": validated,
        "severity": severity
    })


def safe_get(url, **kwargs):
    try:
        return session.get(url, timeout=TIMEOUT, **kwargs)
    except requests.RequestException as e:
        log(f"  ERROR GET {url}: {e}")
        return None


def safe_post(url, **kwargs):
    try:
        return session.post(url, timeout=TIMEOUT, **kwargs)
    except requests.RequestException as e:
        log(f"  ERROR POST {url}: {e}")
        return None


# ---------------------------------------------------------------------------
# 1. WORDPRESS CORE RECON
# ---------------------------------------------------------------------------
def wp_core_recon():
    log("=== 1. WordPress Core Recon ===")

    # 1a. Meta generator / version
    r = safe_get(BASE_URL)
    if r:
        if "generator" in r.text.lower():
            import re
            m = re.search(r'<meta name="generator" content="([^"]+)"', r.text, re.I)
            if m:
                log(f"  Meta generator: {m.group(1)}")
                results["wordpress_core"]["meta_generator"] = m.group(1)

    # 1b. REST API user enumeration validation
    r = safe_get(urljoin(BASE_URL, "wp-json/wp/v2/users"))
    if r and r.status_code == 200:
        try:
            users = r.json()
            usernames = [u.get("slug") or u.get("name") for u in users]
            log(f"  /wp-json/wp/v2/users -> {usernames}")
            results["wordpress_core"]["enumerated_users"] = usernames
            if usernames:
                add_finding(
                    "Username Enumeration via REST API",
                    f"Endpoint /wp-json/wp/v2/users mengembalikan daftar username: {usernames}. "
                    "Ini valid sebagai information disclosure ringan (memudahkan brute-force/credential "
                    "stuffing), TAPI bukan vulnerability berdiri sendiri kecuali dikombinasikan dengan "
                    "lemahnya rate-limiting login atau tidak adanya 2FA.",
                    validated=True,
                    severity="Low"
                )
        except json.JSONDecodeError:
            log("  Response bukan JSON valid")

    # 1c. author archive enumeration (?author=1) cross-check
    r = safe_get(urljoin(BASE_URL, "?author=1"))
    if r:
        log(f"  ?author=1 -> HTTP {r.status_code}, final URL: {r.url}")
        results["wordpress_core"]["author_enum_redirect"] = r.url

    # 1d. xmlrpc.php check
    r = safe_get(urljoin(BASE_URL, "xmlrpc.php"))
    if r:
        log(f"  /xmlrpc.php -> HTTP {r.status_code} (len={len(r.text)})")
        results["wordpress_core"]["xmlrpc_status"] = r.status_code
        if r.status_code == 200 and "XML-RPC server accepts POST" in r.text:
            add_finding(
                "XML-RPC Enabled",
                "xmlrpc.php dapat diakses dan merespons GET dengan pesan default. Berpotensi "
                "disalahgunakan untuk brute-force (system.multicall) atau pingback DDoS relay. "
                "Perlu validasi lanjut apakah method berbahaya (pingback.ping, wp.getUsersBlogs) aktif.",
                validated=False,
                severity="Low-Medium"
            )
        else:
            add_finding(
                "XML-RPC Restricted",
                f"xmlrpc.php mengembalikan status {r.status_code} pada GET, konsisten dengan hasil "
                "reconnaissance awal yang menyatakan 'Restricted'. Tidak ada exploitable behavior "
                "yang teramati pada tahap ini.",
                validated=True,
                severity="Info"
            )

    # 1e. Directory indexing check on common plugin/upload paths
    dirs_to_check = [
        "wp-content/plugins/",
        "wp-content/plugins/visitors-traffic-real-time-statistics/",
        "wp-content/plugins/elementor/",
        "wp-content/uploads/",
    ]
    for d in dirs_to_check:
        r = safe_get(urljoin(BASE_URL, d))
        if r:
            indexing = ("Index of /" in r.text) or ("<title>Index of" in r.text)
            log(f"  {d} -> HTTP {r.status_code}, directory_indexing={indexing}")
            results["wordpress_core"].setdefault("directory_indexing", {})[d] = {
                "status": r.status_code, "indexing_detected": indexing
            }
            if indexing:
                add_finding(
                    f"Directory Indexing Enabled: {d}",
                    "Direktori dapat dibrowse langsung dan menampilkan listing file. Perlu dinilai "
                    "apakah file sensitif (config, backup, log) ikut terekspos di listing tersebut.",
                    validated=True,
                    severity="Low-Medium (tergantung isi direktori)"
                )


# ---------------------------------------------------------------------------
# 2. PLUGIN: visitors-traffic-real-time-statistics (WP Visitor Statistics)
# ---------------------------------------------------------------------------
def plugin_visitor_stats_recon():
    log("=== 2. Plugin: visitors-traffic-real-time-statistics (8.9.1) ===")

    plugin_dir = "wp-content/plugins/visitors-traffic-real-time-statistics/"
    r = safe_get(urljoin(BASE_URL, plugin_dir + "readme.txt"))
    if r and r.status_code == 200:
        first_lines = "\n".join(r.text.splitlines()[:15])
        log(f"  readme.txt found:\n{first_lines}")
        results["plugin_visitors_traffic"]["readme_snippet"] = first_lines

    # Known historical AJAX actions for this plugin family (wp-stats-manager /
    # visitors-traffic-real-time-statistics). We only TEST for presence/behavior,
    # not exploit. This validates whether older-CVE-style handlers still exist
    # and whether they now enforce nonce/capability (i.e. whether patch applied).
    ajax_actions_to_probe = [
        "today_traffic_index",     # historical SQLi vector (CVE-2021-24829), fixed <3.9
        "fixed_db_issue",          # historical unauth DROP TABLE (CVE-2025-49996), fixed 8.5
        "wsm_dismiss_notice",
    ]

    admin_ajax = urljoin(BASE_URL, "wp-admin/admin-ajax.php")

    for action in ajax_actions_to_probe:
        # Unauthenticated probe - benign parameters only, no injection payload.
        r = safe_post(admin_ajax, data={"action": action})
        if r is not None:
            log(f"  action={action} (unauth) -> HTTP {r.status_code}, len={len(r.text)}, "
                f"body_snippet={r.text[:120]!r}")
            results["plugin_visitors_traffic"].setdefault("ajax_probe", {})[action] = {
                "status": r.status_code,
                "len": len(r.text),
                "snippet": r.text[:200]
            }

            # Heuristic validation only - human must confirm via Tamper Data/Burp
            if r.status_code == 200 and ("0" != r.text.strip()) and ("-1" != r.text.strip()):
                add_finding(
                    f"AJAX action '{action}' returned non-default response unauthenticated",
                    "Action ini merespons dengan body selain '0'/'-1' (yang biasanya berarti "
                    "'action not found'/'nonce invalid' di WordPress core), walau tanpa login. "
                    "INI BARU INDIKASI AWAL - wajib divalidasi manual via Tamper Data: cek apakah "
                    "ada current_user_can()/check_ajax_referer() yang di-bypass, dan apakah data "
                    "yang dikembalikan sensitif.",
                    validated=False,
                    severity="Needs Manual Validation"
                )

    # Shortcode-based stored XSS surface (historical CVE pattern: wsm_showDayStatsGraph,
    # wsm_showMostActiveVisitorsGeo, wsm_showLastDaysStatsChart). We do NOT inject payload
    # here (requires authenticated post-editor access); we just note the surface for the
    # manual phase.
    add_finding(
        "Shortcode attributes surface for stored XSS (manual test required)",
        "Versi historis plugin ini punya riwayat stored XSS via atribut shortcode "
        "(wsm_showDayStatsGraph, wsm_showMostActiveVisitorsGeo, wsm_showLastDaysStatsChart) "
        "yang dipatch di 8.3/8.4/8.6. Karena versi lab 8.9.1 > 8.6, kemungkinan sudah "
        "terpatch. WAJIB divalidasi manual: buat post, sisipkan shortcode dengan atribut "
        "berisi karakter HTML benign (mis. attr=\"test<b>bold</b>\"), simpan, lihat apakah "
        "ter-escape di output.",
        validated=False,
        severity="Needs Manual Validation"
    )


# ---------------------------------------------------------------------------
# 3. PLUGIN: elementor (4.1.3)
# ---------------------------------------------------------------------------
def plugin_elementor_recon():
    log("=== 3. Plugin: elementor (4.1.3) ===")

    plugin_dir = "wp-content/plugins/elementor/"
    r = safe_get(urljoin(BASE_URL, plugin_dir + "readme.txt"))
    if r and r.status_code == 200:
        first_lines = "\n".join(r.text.splitlines()[:15])
        log(f"  readme.txt found:\n{first_lines}")
        results["plugin_elementor"]["readme_snippet"] = first_lines

    # Known relevant CVE for THIS exact version:
    #   CVE-2026-57619: Sensitive Data Exposure, <=4.1.3, patched 4.1.4, requires Contributor.
    #   CVE-2026-49782: Missing Authorization/Broken Access Control, <=4.1.0, patched 4.1.1
    #     -> lab version 4.1.3 is ALREADY PATCHED for this one (4.1.3 > 4.1.1). Still
    #        worth a quick negative-confirmation test.
    #   CVE-2026-6127: Stored XSS via _elementor_data (form-encoded PATCH bypass sanitize),
    #     <=4.0.4, patched 4.0.5. Lab version 4.1.3 > 4.0.5 -> already patched, negative test only.
    #
    # We only test with GET/read-only or clearly non-destructive authenticated flows.
    # This script CANNOT authenticate for you (contributor credentials needed) - it only
    # probes the REST route existence & response to unauthenticated calls, and prints
    # the exact manual steps for the Tamper Data phase.

    rest_routes_to_check = [
        "wp-json/elementor/v1/globals",
        "wp-json/elementor/v1/globals/colors",
        "wp-json/elementor/v1/globals/typography",
        "wp-json/elementor/v1/forms",
    ]
    for route in rest_routes_to_check:
        r = safe_get(urljoin(BASE_URL, route))
        if r is not None:
            log(f"  {route} (unauth) -> HTTP {r.status_code}, len={len(r.text)}")
            results["plugin_elementor"].setdefault("rest_probe", {})[route] = {
                "status": r.status_code, "len": len(r.text)
            }
            if r.status_code == 200:
                add_finding(
                    f"Elementor REST route '{route}' accessible unauthenticated",
                    "Route merespons 200 tanpa autentikasi. Perlu diperiksa manual apakah "
                    "response berisi data sensitif (email internal, draft content, config) - "
                    "relevan terhadap pola CVE-2026-57619 (Sensitive Data Exposure, "
                    "<=4.1.3, requires Contributor - jadi tetap butuh kredensial contributor "
                    "untuk exploit penuh, namun endpoint discovery ini tetap dicatat).",
                    validated=False,
                    severity="Needs Manual Validation"
                )

    add_finding(
        "CVE-2026-57619 applicability check (Elementor Sensitive Data Exposure)",
        "Versi terpasang 4.1.3 PERSIS berada dalam rentang vulnerable (<=4.1.3, "
        "patched 4.1.4), required privilege: Contributor. WAJIB divalidasi manual dengan "
        "akun contributor: login sebagai contributor, intercept request ke REST API terkait "
        "post/page meta melalui Tamper Data, periksa apakah field sensitif (mis. data user lain, "
        "meta internal) terekspos pada response yang seharusnya dibatasi untuk role contributor.",
        validated=False,
        severity="High Priority - Needs Manual Validation (matches unpatched version range)"
    )

    add_finding(
        "CVE-2026-49782 negative-confirmation check (Missing Authorization, patched <=4.1.0)",
        "Versi terpasang 4.1.3 lebih baru dari versi patch (4.1.1), sehingga kemungkinan "
        "besar SUDAH TERPATCH. Tetap disarankan 1x uji negatif cepat untuk konfirmasi bahwa "
        "authorization check yang relevan memang berfungsi di versi ini.",
        validated=False,
        severity="Low Priority - Likely Patched"
    )

    add_finding(
        "CVE-2026-6127 negative-confirmation check (Stored XSS via _elementor_data, patched <=4.0.4)",
        "Versi terpasang 4.1.3 lebih baru dari versi patch (4.0.5), sehingga kemungkinan "
        "besar SUDAH TERPATCH. Tetap disarankan uji negatif: kirim PATCH form-encoded ke "
        "wp-json/wp/v2/pages/{id} dengan field meta._elementor_data berisi karakter HTML "
        "benign, dan pastikan tersanitasi/ter-reject.",
        validated=False,
        severity="Low Priority - Likely Patched"
    )


# ---------------------------------------------------------------------------
# 4. Plugin/Core update status cross-check
# ---------------------------------------------------------------------------
def update_status_summary():
    add_finding(
        "Plugin Needs Updating - visitors-traffic-real-time-statistics",
        "Terpasang: 8.9.1, Latest: 8.11. Perlu dicek changelog resmi antara 8.9.1 -> 8.11 "
        "untuk memastikan apakah ada security fix yang terlewat (bukan cuma feature update).",
        validated=True,
        severity="Info/Low - confirm changelog"
    )
    add_finding(
        "Plugin Needs Updating - elementor",
        "Terpasang: 4.1.3, Latest: 4.2.1. CVE-2026-57619 (Sensitive Data Exposure) baru "
        "dipatch di 4.1.4, artinya versi lab TERMASUK RENTANG VULNERABLE. Ini prioritas "
        "validasi tertinggi pada assessment ini.",
        validated=True,
        severity="Medium-High - confirmed vulnerable version range"
    )


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    log(f"Target: {BASE_URL}")
    log(f"Proxy (for Tamper Data/Burp interception): {PROXIES}")
    log("Pastikan proxy listener sudah aktif jika USE_PROXY=True.\n")

    wp_core_recon()
    plugin_visitor_stats_recon()
    plugin_elementor_recon()
    update_status_summary()

    out_path = "wp_recon_results.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    log(f"\nSelesai. Hasil tersimpan di {out_path}")
    log(f"Total findings: {len(results['findings'])}")
    for finding in results["findings"]:
        status = "VALIDATED" if finding["validated"] else "NEEDS MANUAL VALIDATION"
        log(f"  [{status}] ({finding['severity']}) {finding['title']}")
