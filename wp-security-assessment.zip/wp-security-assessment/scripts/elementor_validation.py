#!/usr/bin/env python3
"""
Elementor 4.1.3 - Targeted Validation Script
==============================================
Fokus: CVE-2026-57619 (Sensitive Data Exposure, <=4.1.3, Contributor-level)
       + negative-confirmation untuk CVE-2026-49782 & CVE-2026-6127 (harusnya patched)

PENTING:
- Script ini butuh KREDENSIAL akun Contributor yang sudah dibuat di lab Anda.
- Semua request lewat proxy (Tamper Data/Burp/ZAP) agar bisa diintercept &
  dimodifikasi manual sesuai instruksi di REPORT_TEMPLATE.md.
- TIDAK ADA payload destruktif. Payload XSS test hanya karakter HTML benign
  dan HARUS dihapus/dibersihkan setelah pengujian (post dihapus).

Usage:
    pip install requests
    python elementor_validation.py
"""

import requests
import json
import sys
from datetime import datetime
from urllib.parse import urljoin

BASE_URL = "http://localhost/WordpressLabReseacher/"
PROXIES = {"http": "http://127.0.0.1:8080", "https": "http://127.0.0.1:8080"}
VERIFY_SSL = False
TIMEOUT = 10

# ISI DENGAN KREDENSIAL LAB ANDA SENDIRI (akun contributor test, bukan admin utama)
CONTRIBUTOR_USER = "contributor_test"
CONTRIBUTOR_PASS = "CHANGE_ME"

requests.packages.urllib3.disable_warnings()


def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")


def get_authenticated_session():
    """
    Login via wp-login.php form (cookie-based), karena REST API application
    password lebih baik untuk test resmi. Sesuaikan jika lab pakai Application
    Passwords (disarankan - lebih bersih untuk audit trail).
    """
    s = requests.Session()
    s.proxies = PROXIES
    s.verify = VERIFY_SSL

    login_url = urljoin(BASE_URL, "wp-login.php")
    r = s.get(login_url, timeout=TIMEOUT)
    log(f"GET wp-login.php -> {r.status_code}")

    payload = {
        "log": CONTRIBUTOR_USER,
        "pwd": CONTRIBUTOR_PASS,
        "wp-submit": "Log In",
        "redirect_to": urljoin(BASE_URL, "wp-admin/"),
        "testcookie": "1",
    }
    r = s.post(login_url, data=payload, timeout=TIMEOUT, allow_redirects=True)
    log(f"POST wp-login.php -> {r.status_code}, final url: {r.url}")

    if "wp-admin" in r.url and "wp-login" not in r.url:
        log("Login tampak berhasil (redirected to wp-admin).")
        return s
    else:
        log("WARNING: Login mungkin gagal. Periksa kredensial CONTRIBUTOR_USER/PASS.")
        return s


def get_nonce(session):
    """Ambil REST nonce dari halaman admin (dibutuhkan untuk request REST API dari dalam wp-admin context)."""
    r = session.get(urljoin(BASE_URL, "wp-admin/admin-ajax.php"), timeout=TIMEOUT)
    # Nonce sesungguhnya biasanya perlu diparsing dari halaman editor.
    # Sarankan ambil manual dari DevTools/Tamper Data: cari header X-WP-Nonce
    # pada request yang dibuat oleh browser saat contributor membuka Elementor editor.
    log("Catatan: ambil X-WP-Nonce yang sesungguhnya dari intercept Tamper Data/Burp "
        "saat contributor membuka halaman edit post di wp-admin. Nonce hardcode di "
        "script ini TIDAK reliable karena bersifat per-session/per-user.")
    return None


def test_cve_2026_57619_sensitive_data_exposure(session):
    """
    Uji apakah REST API mengekspos data sensitif ke akun Contributor yang
    seharusnya tidak boleh melihat data tsb (post orang lain / meta internal).
    """
    log("=== Test CVE-2026-57619: Sensitive Data Exposure (Contributor-level) ===")

    endpoints_to_check = [
        "wp-json/wp/v2/pages?status=any&per_page=50",
        "wp-json/wp/v2/posts?status=any&per_page=50",
        "wp-json/wp/v2/users?context=edit",
    ]

    for ep in endpoints_to_check:
        r = session.get(urljoin(BASE_URL, ep), timeout=TIMEOUT)
        log(f"  GET {ep} -> {r.status_code}")
        if r.status_code == 200:
            try:
                data = r.json()
                log(f"    Jumlah item: {len(data) if isinstance(data, list) else 'n/a'}")
                # Cek apakah ada post berstatus draft/private yang dibuat user LAIN
                if isinstance(data, list):
                    for item in data:
                        status = item.get("status")
                        author = item.get("author")
                        if status in ("draft", "private", "pending"):
                            log(f"    [PERHATIAN] Post id={item.get('id')} status={status} "
                                f"author={author} terlihat oleh contributor - "
                                "VALIDASI MANUAL apakah ini post milik user lain "
                                "(bukan milik contributor_test sendiri).")
            except json.JSONDecodeError:
                log("    Response bukan JSON valid")
        elif r.status_code == 401 or r.status_code == 403:
            log(f"    Endpoint menolak akses ({r.status_code}) - konsisten dengan sudah terpatch "
                "atau access control berfungsi normal.")


def test_cve_2026_49782_negative_check(session):
    """
    Negative-confirmation: pastikan broken access control YANG SUDAH DIPATCH di 4.1.1
    memang tidak lagi bisa dieksploitasi di 4.1.3.
    """
    log("=== Negative Check CVE-2026-49782 (Missing Authorization, patched <=4.1.0) ===")
    # Endpoint spesifik tergantung advisory detail; secara umum uji akses ke
    # elementor settings/template routes yang harusnya admin-only.
    endpoints = [
        "wp-json/elementor/v1/globals",
        "wp-json/elementor/v1/templates",
    ]
    for ep in endpoints:
        r = session.get(urljoin(BASE_URL, ep), timeout=TIMEOUT)
        log(f"  GET {ep} (as contributor) -> {r.status_code}")
        if r.status_code in (401, 403):
            log("    Baik - akses ditolak, konsisten dengan patch berfungsi.")
        elif r.status_code == 200:
            log("    [PERLU VALIDASI MANUAL] Endpoint dapat diakses - cek apakah ini "
                "expected behavior (public data) atau indikasi regression.")


def test_cve_2026_6127_negative_check(session):
    """
    Negative-confirmation: pastikan form-encoded PATCH ke _elementor_data
    SUDAH tersanitasi/ditolak di versi 4.1.3 (patch ada di 4.0.5).
    Payload benign HTML saja, BUKAN script eksekusi nyata, dan post test
    HARUS dihapus setelah pengujian.
    """
    log("=== Negative Check CVE-2026-6127 (Stored XSS via _elementor_data, patched <=4.0.4) ===")

    # 1. Buat draft post benign sebagai contributor
    create_payload = {
        "title": "Security-Test-Draft-DELETE-ME",
        "status": "draft",
        "content": "Draft sementara untuk validasi non-destruktif."
    }
    r = session.post(urljoin(BASE_URL, "wp-json/wp/v2/pages"), json=create_payload, timeout=TIMEOUT)
    log(f"  POST create draft page -> {r.status_code}")
    if r.status_code not in (200, 201):
        log("  Tidak bisa membuat draft (mungkin contributor tidak punya izin buat page). "
            "Coba endpoint /wp-json/wp/v2/posts sebagai gantinya, atau skip test ini.")
        return

    post_id = r.json().get("id")
    log(f"  Draft dibuat, id={post_id}")

    # 2. Kirim PATCH form-encoded (bukan JSON) berisi karakter HTML benign di meta
    #    untuk menguji apakah sanitize_callback berfungsi (harusnya SUDAH terpatch).
    benign_test_string = 'test-value-<b>bold-marker</b>-nonexecutable'
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    patch_data = f"meta[_elementor_data]={benign_test_string}"

    r = session.request(
        "PATCH",
        urljoin(BASE_URL, f"wp-json/wp/v2/pages/{post_id}"),
        data=patch_data,
        headers=headers,
        timeout=TIMEOUT
    )
    log(f"  PATCH (form-encoded) meta._elementor_data -> {r.status_code}")

    # 3. Verifikasi: ambil kembali post, lihat apakah string tersanitasi atau lolos mentah
    r2 = session.get(urljoin(BASE_URL, f"wp-json/wp/v2/pages/{post_id}?context=edit"), timeout=TIMEOUT)
    if r2.status_code == 200:
        body = r2.text
        if benign_test_string in body:
            log("  [TEMUAN POTENSIAL] String HTML mentah ditemukan tidak tersanitasi dalam "
                "response - VALIDASI LEBIH LANJUT diperlukan (bandingkan dengan behavior "
                "yang dijelaskan di CVE-2026-6127). Kemungkinan regression jika versi 4.1.3 "
                "seharusnya sudah patched.")
        else:
            log("  Baik - string tidak ditemukan mentah, konsisten dengan sanitasi berfungsi "
                "(sesuai ekspektasi versi patched).")

    # 4. CLEANUP - hapus post test (non-destruktif, wajib dilakukan)
    r3 = session.delete(urljoin(BASE_URL, f"wp-json/wp/v2/pages/{post_id}?force=true"), timeout=TIMEOUT)
    log(f"  Cleanup: DELETE draft test page -> {r3.status_code}")


if __name__ == "__main__":
    log("Memulai validasi Elementor 4.1.3 (butuh kredensial contributor lab)")
    if CONTRIBUTOR_PASS == "CHANGE_ME":
        log("ERROR: Ganti CONTRIBUTOR_USER/CONTRIBUTOR_PASS dengan kredensial akun "
            "contributor test di lab Anda sebelum menjalankan script ini.")
        sys.exit(1)

    sess = get_authenticated_session()
    get_nonce(sess)
    test_cve_2026_57619_sensitive_data_exposure(sess)
    test_cve_2026_49782_negative_check(sess)
    test_cve_2026_6127_negative_check(sess)

    log("\nSelesai. Cocokkan hasil di atas dengan traffic yang ter-capture di "
        "Tamper Data/Burp untuk analisis manual mendalam (header, nonce, response body lengkap).")
