# WP Security Assessment Lab Kit

Paket lengkap untuk security assessment WordPress + plugin (Elementor,
WP Visitor Statistics) di lab lokal `http://localhost/WordpressLabReseacher/`.

## Struktur

```
wp-security-assessment/
├── scripts/
│   ├── wp_recon.py              # Recon awal + baseline non-destruktif (core, kedua plugin)
│   └── elementor_validation.py  # Validasi CVE-2026-57619 (Elementor, butuh akun contributor)
├── upload-test/
│   ├── elementor_upload_test.py         # Test upload benign ke Elementor Form widget
│   ├── UPLOAD_TEST_ANALYSIS_GUIDE.md    # Cara analisis hasil test upload
│   └── test-files/
│       ├── test.jpg
│       ├── test.png
│       └── test.txt
└── reports/
    ├── TAMPER_DATA_GUIDE.md     # Panduan manual intercept via Tamper Data/Burp/ZAP
    └── REPORT_TEMPLATE.md       # Template dokumentasi temuan final
```

## Quickstart di Termux

```bash
# 1. Extract
unzip wp-security-assessment.zip
cd wp-security-assessment

# 2. Install dependency
pip install requests

# 3. Pastikan Termux bisa akses target lab
#    Jika lab jalan di HP yang sama (XAMPP di Termux/proot atau device lain
#    di jaringan yang sama), sesuaikan BASE_URL di tiap script -
#    "localhost" hanya valid kalau XAMPP jalan di device yang SAMA dengan Termux.
#    Kalau XAMPP jalan di PC lain, ganti BASE_URL jadi IP PC tsb,
#    misal http://192.168.1.10/WordpressLabReseacher/

# 4. Jalankan recon awal
python scripts/wp_recon.py

# 5. Isi kredensial contributor di scripts/elementor_validation.py, lalu jalankan
python scripts/elementor_validation.py

# 6. Untuk test upload, isi konfigurasi form di upload-test/elementor_upload_test.py
python upload-test/elementor_upload_test.py
```

## Proxy (Tamper Data pengganti) di Termux

Tamper Data (ekstensi Firefox) sudah deprecated. Opsi di Termux/Android:

- **HTTP Toolkit** (app Android terpisah, GUI intercept mirip Burp) — paling gampang di mobile.
- **mitmproxy** via Termux:
  ```bash
  pkg install python
  pip install mitmproxy
  mitmproxy --listen-port 8080
  ```
  Lalu set proxy WiFi device ke `<ip-termux>:8080`, install sertifikat mitmproxy
  di browser/device (buka `mitm.it` setelah proxy aktif).
- **Burp Suite** biasanya butuh device terpisah (laptop) karena GUI berat untuk Termux — jalankan Burp di PC, arahkan `PROXIES` di script Python (jika dijalankan dari PC) atau proxy WiFi HP ke IP PC tsb.

Semua script sudah punya `PROXIES = {"http": "http://127.0.0.1:8080", ...}` —
sesuaikan IP:port sesuai proxy yang dipakai (localhost kalau proxy jalan di
device yang sama, atau IP proxy kalau di device lain).

## Urutan Kerja yang Disarankan

1. `scripts/wp_recon.py` — baseline semua endpoint (unauthenticated, aman dijalankan kapan saja)
2. `reports/TAMPER_DATA_GUIDE.md` — ikuti manual testing step-by-step sambil proxy aktif
3. `scripts/elementor_validation.py` — validasi CVE-2026-57619 (assign kredensial contributor dulu)
4. `upload-test/elementor_upload_test.py` + `UPLOAD_TEST_ANALYSIS_GUIDE.md` — test upload benign
5. `reports/REPORT_TEMPLATE.md` — tulis semua temuan yang berhasil direproduksi

## Catatan Penting

- Semua script **non-destruktif** — tidak ada payload executable, tidak ada DROP TABLE, tidak ada file berbahaya.
- Hanya jalankan terhadap target lab yang Anda miliki/diizinkan secara eksplisit.
- Temuan hanya didokumentasikan jika **berhasil direproduksi**, bukan sekadar indikasi awal.
