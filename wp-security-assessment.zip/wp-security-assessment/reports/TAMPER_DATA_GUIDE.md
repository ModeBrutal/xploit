# Panduan Pengujian Manual dengan Tamper Data / HTTP Proxy

Target: `http://localhost/WordpressLabReseacher/`
Metodologi: Black-box, non-destruktif

> Catatan: Tamper Data (ekstensi Firefox lawas) sudah deprecated. Gunakan
> pengganti fungsional yang setara: **Burp Suite Community**, **OWASP ZAP**,
> atau **Tamper Chrome / Requestly**. Semua instruksi di bawah kompatibel
> dengan proxy manapun yang bisa intercept & modify request.

## 0. Setup

1. Jalankan proxy (Burp/ZAP) di `127.0.0.1:8080`.
2. Arahkan browser lab ke proxy tersebut (atau gunakan FoxyProxy).
3. Import sertifikat CA proxy ke browser jika target pakai HTTPS.
4. Set `USE_PROXY = True` di `wp_recon.py` / `elementor_validation.py` agar traffic script Python juga tercapture di proxy yang sama (untuk cross-check).

---

## 1. Plugin: visitors-traffic-real-time-statistics (8.9.1)

### 1.1 Identifikasi AJAX handler aktif

1. Login sebagai `admin` atau `editor`, buka dashboard WordPress.
2. Buka menu plugin ini (Visitor Statistics dashboard).
3. Di proxy, filter request ke `admin-ajax.php`.
4. Catat setiap `action=` yang terkirim (contoh historis: `today_traffic_index`, `fixed_db_issue`, `wsm_dismiss_notice`, dll — **nama action bisa berbeda di 8.9.1**, verifikasi dari traffic asli).

### 1.2 Uji nonce & capability

Untuk setiap action yang ditemukan:

1. **Intercept** request POST ke `admin-ajax.php`.
2. **Forward tanpa modifikasi dulu** — catat response normal (baseline).
3. **Tamper**: hapus/kosongkan parameter `_wpnonce` atau `security`, forward ulang.
   - Jika response tetap sukses (bukan error nonce) → **berpotensi CSRF/broken nonce validation**, catat sebagai temuan butuh validasi.
4. **Tamper**: ganti session cookie ke akun role lebih rendah (subscriber jika ada) atau hapus cookie sepenuhnya (logout state), forward ulang request yang sama persis (replay).
   - Jika response tetap sukses tanpa login → **berpotensi missing `current_user_can()` check**.

### 1.3 Uji parameter yang bisa dikontrol user (indikasi SQLi)

1. Cari parameter yang terlihat dipakai untuk filter/query, misalnya `date`, `id`, `filter`, `country`.
2. Tamper nilai parameter dengan karakter **non-destruktif** untuk deteksi anomali sintaks:
   - `'` (single quote) → lihat apakah muncul SQL error di response/error log.
   - `1' AND '1'='1` vs `1' AND '1'='2` → bandingkan response (boolean-based blind indicator).
   - **JANGAN** gunakan payload UNION SELECT atau time-based (`SLEEP()`) tanpa izin eksplisit tambahan, karena berisiko membebani DB lab.
3. Dokumentasikan HANYA jika ada perbedaan response yang konsisten dan reproducible.

### 1.4 Uji shortcode stored XSS (jika role memungkinkan edit post)

1. Buat post/page baru, sisipkan shortcode plugin (mis. yang menampilkan grafik) dengan atribut berisi karakter benign: `attr="test&lt;b&gt;bold&lt;/b&gt;"` atau `attr='"><b>test</b>'`.
2. Save/preview post.
3. Di proxy, cek response HTML: apakah karakter `< >` ter-escape (`&lt;` `&gt;`) atau lolos mentah sebagai tag HTML.
4. **Jika lolos mentah** → screenshot response body, ini indikasi kuat stored XSS (masih perlu 1x replikasi ulang untuk konfirmasi).
5. **Cleanup**: hapus post test setelah selesai.

---

## 2. Plugin: Elementor (4.1.3) — Prioritas: CVE-2026-57619

### 2.1 Setup akun Contributor

1. Buat/pastikan ada akun role **Contributor** di lab (bukan admin).
2. Login sebagai contributor di browser dengan proxy aktif.

### 2.2 Validasi Sensitive Data Exposure

1. Buka Elementor editor pada draft milik contributor tersebut.
2. Di proxy, catat semua request ke `/wp-json/elementor/v1/*` dan `/wp-json/wp/v2/*` — termasuk header `X-WP-Nonce`.
3. **Tamper**: ubah parameter `id` post pada request GET (mis. `wp-json/wp/v2/pages/{id}`) menjadi ID post/page **milik user lain** (termasuk draft/private milik admin, jika Anda tahu ID-nya dari recon awal).
4. Forward request. Periksa response:
   - Jika contributor **berhasil melihat konten/meta post yang bukan miliknya** (terutama draft/private) → ini validasi konkret CVE-2026-57619.
   - Jika response `401`/`403`/`rest_forbidden` → access control masih berfungsi, catat sebagai negative-confirmation.
5. Ulangi untuk endpoint `wp-json/wp/v2/users?context=edit` — cek apakah field sensitif (email) user lain terekspos ke contributor.

### 2.3 Negative-check CVE-2026-49782 & CVE-2026-6127 (harusnya sudah patched)

1. Untuk CVE-2026-49782: ulangi pola pengujian broken-access-control di atas terhadap endpoint global Elementor settings (`wp-json/elementor/v1/globals`), sebagai contributor. Harusnya ditolak (403).
2. Untuk CVE-2026-6127: gunakan `elementor_validation.py` bagian `test_cve_2026_6127_negative_check` sebagai baseline otomatis, lalu **replay manual** request PATCH form-encoded yang sama via proxy dengan variasi:
   - Content-Type `application/x-www-form-urlencoded` (harus tersanitasi/gagal karena versi patched).
   - Content-Type `application/json` (jalur normal, harus tersanitasi juga).
3. Bandingkan response body — pastikan karakter HTML test ter-escape/tersanitasi di kedua kasus.

---

## 3. WordPress Core — Validasi Tambahan

### 3.1 Username enumeration → cek dampak nyata

1. Ambil daftar username dari `/wp-json/wp/v2/users`.
2. Coba login dengan username tersebut + password salah **1 kali saja** (jangan brute force).
3. Bandingkan pesan error: apakah WordPress membedakan "username salah" vs "password salah"? Jika ya → memperkuat validitas username enum sebagai risiko (mempermudah credential stuffing terarah).

### 3.2 Directory indexing → cek isi

1. Untuk setiap direktori dengan indexing aktif (dari hasil `wp_recon.py`), buka manual di browser/proxy.
2. Screenshot listing file. Cek apakah ada file sensitif: `.sql`, `.bak`, `wp-config.php.bak`, `debug.log`, dsb.
3. Jika tidak ada file sensitif di listing → downgrade severity jadi Informational saja (indexing enabled tapi no real impact).

---

## 4. Reporting

Gunakan `REPORT_TEMPLATE.md` untuk setiap temuan yang **berhasil direproduksi**.
Jika tidak ada temuan valid pada suatu area pengujian, tuliskan secara eksplisit:

> "No vulnerability identified during the tested scenarios."

Jangan mendokumentasikan indikasi awal sebagai vulnerability final tanpa reproduksi manual.
